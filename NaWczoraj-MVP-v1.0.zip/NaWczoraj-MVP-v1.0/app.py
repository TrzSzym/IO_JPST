import os
import click
from flask import Flask, redirect, url_for
from db import close_db, ensure_db_initialized, init_db
from controllers.klient import bp as klient_bp
from controllers.spedytor import bp as spedytor_bp
from controllers.przewoznik import bp as przewoznik_bp
from controllers.magazynier import bp as magazynier_bp
from controllers.sledzenie import bp as sledzenie_bp


def create_app(test_config=None) -> Flask:
    app = Flask(__name__)
    root_dir = os.path.dirname(os.path.abspath(__file__))

    app.config.from_mapping(
        SECRET_KEY="nawczoraj-mvp-v1-secret-key",
        DATABASE=os.path.join(root_dir, "nawczoraj.db"),
        UPLOAD_FOLDER=os.path.join(root_dir, "static", "uploads", "pod"),
        MAX_CONTENT_LENGTH=16 * 1024 * 1024,
    )

    if test_config is not None:
        app.config.update(test_config)

    app.teardown_appcontext(close_db)

    app.register_blueprint(klient_bp)
    app.register_blueprint(spedytor_bp)
    app.register_blueprint(przewoznik_bp)
    app.register_blueprint(magazynier_bp)
    app.register_blueprint(sledzenie_bp)

    @app.cli.command("init-db")
    def init_db_command():
        """Inicjalizuje strukturę bazy SQLite oraz dane demonstracyjne."""
        init_db(seed=True)
        click.echo("Zainicjalizowano bazę danych systemu NaWczoraj (schema.sql + seed.sql).")

    @app.get("/")
    def index():
        return redirect(url_for("klient.panel"))

    if not app.config.get("TESTING"):
        ensure_db_initialized(app)

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
