# System Spedycyjny „NaWczoraj” – MVP v1.0.0

Aplikacja webowa wspierająca obsługę zleceń spedycyjnych i transportowych w polskiej firmie spedycyjnej **„NaWczoraj”**, zrealizowana w architekturze **MVC (Model–Widok–Kontroler)** w ramach przedmiotu *Inżynieria Oprogramowania / Projektowanie Systemów Informatycznych* (UWM Olsztyn).

Zespół projektowy: **Jakub Pryzmont, Kamila Ignatowska**  
Prowadzący: **mgr inż. Artur Samojluk**

---

## 1. Zakres funkcjonalny MVP (v1.0)

| ID | Przypadki użycia | Opis funkcjonalności | Widok |
| :--- | :--- | :--- | :--- |
| **F01** | UC4 / UC10 / UC5 / UC7 | Złożenie zapytania o zlecenie przez Klienta, wycena netto przez Spedytora oraz akceptacja i opłacenie wyceny (`Nowe` → `Wycenione` → `Opłacone`). | **W01**, **W02** |
| **F02** | UC3 / UC13 | Planowanie i zlecanie transportu: przypisanie Przewoźnika do opłaconego zlecenia z walidacją dostępności pojazdu w terminie oraz ładowności (`Opłacone` → `W transporcie`). | **W02** |
| **F03** | UC2 | Śledzenie statusu i bieżącej lokalizacji przesyłki po unikalnym numerze zlecenia (`nr_zlecenia`, np. `ZL/2026/0003`). | **W01**, **W03**, `/sledzenie` |
| **F04** | UC9 / UC12 | Wgrywanie dokumentu przewozowego POD (`JPG`, `PNG`, `PDF`) przez Przewoźnika oraz weryfikacja dokumentu i zamknięcie/rozliczenie zlecenia przez Spedytora (`W transporcie` → `Zrealizowane`). | **W03**, **W02** |
| **W04** | UC8 | Obsługa przyjmowania i wydawania towaru na rampie magazynowej (Łódź, Warszawa, Poznań, Katowice). | **W04** |

---

## 2. Architektura projektu (MVC)

```text
NaWczoraj-MVP-v1.0/
├── app.py                  # Inicjalizacja aplikacji Flask, rejestracja Blueprintów i komenda CLI init-db
├── db.py                   # Połączenie SQLite (PRAGMA foreign_keys = ON), inicjalizacja bazy
├── schema.sql              # Schemat relacyjnej bazy danych (PK, FK, więzy spójności)
├── seed.sql                # Konta demonstracyjne oraz zlecenia startowe
├── requirements.txt        # Zależności Python (Flask)
├── models/                 # MODEL (M) – reguły biznesowe, walidacje i zapytania SQL
│   ├── uzytkownik.py
│   ├── zlecenie.py
│   └── dokument_pod.py
├── controllers/            # KONTROLER (C) – Blueprinty Flask obsługujące żądania HTTP GET/POST
│   ├── klient.py           # /klient (W01)
│   ├── spedytor.py         # /spedytor (W02)
│   ├── przewoznik.py       # /przewoznik (W03)
│   ├── magazynier.py       # /magazynier (W04)
│   └── sledzenie.py        # /sledzenie (F03)
├── templates/              # WIDOK (V) – szablony HTML Jinja2
├── static/                 # Style CSS oraz katalog uploads/pod/ na pliki POD
├── tests/                  # Testy jednostkowe i integracyjne (test_mvp.py)
└── docs/                   # Dokumentacja wymagana w Laboratorium 03 i 04
    ├── technologie.md
    ├── architektura-mvc.md
    ├── prompty-mvc-v1.0.md
    └── testy-v1.0.md
```

---

## 3. Instrukcja instalacji i uruchomienia

Wymagany **Python 3.10+**.

### Windows (PowerShell)
```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m flask --app app init-db
.\.venv\Scripts\python.exe -m flask --app app run
```

### Linux / macOS
```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m flask --app app init-db
.venv/bin/python -m flask --app app run
```

Po uruchomieniu otwórz w przeglądarce adres: **`http://127.0.0.1:5000`**  
Zatrzymanie serwera: **`Ctrl + C`**. Dane zapisywane są trwale w lokalnym pliku **`nawczoraj.db`** (zachowują się po restarcie serwera).

---

## 4. Konta demonstracyjne i dane startowe

Aplikacja posiada przełącznik ról w górnym pasku nawigacji (`W01`–`W04` oraz `F03`) oraz wybór użytkowników demonstracyjnych w panelach:

* **Klient #1 (Kontraktowy):** *Firma Transportowo-Handlowa XYZ* (`kontakt@xyz-transport.pl`)
* **Klient #2 (Jednorazowy):** *Januszex sp.j.* (`biuro@januszex.pl`)
* **Spedytor #3:** *Jan Kowalski* (`j.kowalski@nawczoraj.pl`)
* **Przewoźnik #4 (Zestaw 24t):** *Trans-Pol Sp. z o.o.* (`EL 4829K`, ładowność `24 000 kg`)
* **Przewoźnik #5 (Solówka 3.5t):** *Szybki-Trans Bus* (`WZ 9102M`, ładowność `3 500 kg`)
* **Magazynier #6:** *Marek Nowak* (Magazyn Centralny Łódź)

Przykładowe zlecenia w bazie startowej:
* **`ZL/2026/0001`** – status `Nowe` (gotowe do przetestowania wyceny przez spedytora w W02).
* **`ZL/2026/0002`** – status `Opłacone`, waga `11 500 kg` (gotowe do przetestowania przydziału przewoźnika w W02; wybranie przewoźnika #5 o ładowności 3 500 kg wywoła komunikat walidacji).
* **`ZL/2026/0003`** – status `W transporcie` (gotowe do przetestowania śledzenia F03, obsługi rampy W04 oraz wgrania pliku POD i rozliczenia w F04).

---

## 5. Uruchomienie testów automatycznych

```bash
python -m unittest discover -s tests -v
```
