PRAGMA foreign_keys = ON;

INSERT OR IGNORE INTO Uzytkownicy (id_uzytkownika, email, haslo, typ_uzytkownika, nazwa_wyswietlana) VALUES
    (1, 'kontakt@xyz-transport.pl', 'demo123', 'Klient', 'Firma Transportowo-Handlowa XYZ'),
    (2, 'biuro@januszex.pl', 'demo123', 'Klient', 'Januszex sp.j.'),
    (3, 'j.kowalski@nawczoraj.pl', 'demo123', 'Spedytor', 'Jan Kowalski (Spedytor)'),
    (4, 'dyspozycja@transpol.pl', 'demo123', 'Przewoznik', 'Trans-Pol Sp. z o.o.'),
    (5, 'flota@szybkitrans.pl', 'demo123', 'Przewoznik', 'Szybki-Trans Bus'),
    (6, 'magazyn.lodz@nawczoraj.pl', 'demo123', 'Magazynier', 'Marek Nowak (Magazyn Centralny Łódź)');

INSERT OR IGNORE INTO Klienci (id_klienta, telefon, miasto, typ_klienta, nazwa_podmiotu, nip) VALUES
    (1, '+48 501 234 567', 'Warszawa', 'Kontraktowy', 'Firma Transportowo-Handlowa XYZ', '9982312231'),
    (2, '+48 602 987 654', 'Łódź', 'Jednorazowy', 'Januszex sp.j.', '1129983211');

INSERT OR IGNORE INTO Spedytorzy (id_spedytora, poziom_uprawnien, region) VALUES
    (3, 2, 'Polska Centralna i Północna');

INSERT OR IGNORE INTO Przewoznici (id_przewoznika, nazwa_przewoznika, nr_rejestracyjny, ladownosc) VALUES
    (4, 'Trans-Pol Sp. z o.o. (Ciągnik + Naczepa 24t)', 'EL 4829K', 24000.0),
    (5, 'Szybki-Trans Bus (Solówka 3.5t)', 'WZ 9102M', 3500.0);

INSERT OR IGNORE INTO Zlecenia (
    id_zlecenia, id_klienta, id_spedytora, id_przewoznika, nr_zlecenia,
    rodzaj_towaru, waga_kg, wymagana_chlodnia, miejsce_zaladunku, miejsce_rozladunku,
    data_zaladunku, uwagi, status, cena_netto, aktualna_lokalizacja, status_rampy, rampa_nr
) VALUES
    (
        1, 1, NULL, NULL, 'ZL/2026/0001',
        'Palety EUR – Elektronika użytkowa', 4200.0, 0, 'Łódź, 90-001', 'Warszawa, 00-844',
        '2026-11-20', 'Wymagana winda rozładunkowa', 'Nowe', NULL,
        'Oczekuje na wycenę spedytora', 'Oczekuje na awizację', NULL
    ),
    (
        2, 1, 3, NULL, 'ZL/2026/0002',
        'Części samochodowe na paletach', 11500.0, 0, 'Poznań, 61-001', 'Katowice, 40-001',
        '2026-11-22', 'Załadunek boczny w magazynie Poznań', 'Opłacone', 2850.00,
        'Opłacone – oczekuje na przydział przewoźnika', 'Awizowane – Rampa 2', 'Rampa 2 (Poznań)'
    ),
    (
        3, 2, 3, 4, 'ZL/2026/0003',
        'Artykuły spożywcze suche (18 palet)', 14000.0, 0, 'Łódź, 93-492', 'Gdańsk, 80-001',
        '2026-11-18', 'Kontakt z odbiorcą 1h przed dostawą', 'W transporcie', 3400.00,
        'Autostrada A1 – okolice Torunia (w trasie)', 'Wydano z rampy', 'Rampa 1 (Łódź)'
    );
