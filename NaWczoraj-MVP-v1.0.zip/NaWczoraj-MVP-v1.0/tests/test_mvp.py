import io
import os
import tempfile
import unittest
from app import create_app
from db import init_db


class NaWczorajMVPTestCase(unittest.TestCase):
    def setUp(self):
        self.db_fd, self.db_path = tempfile.mkstemp(suffix=".db")
        self.upload_dir = tempfile.mkdtemp()
        self.app = create_app(
            {
                "TESTING": True,
                "DATABASE": self.db_path,
                "UPLOAD_FOLDER": self.upload_dir,
            }
        )
        with self.app.app_context():
            init_db(seed=True)
        self.client = self.app.test_client()

    def tearDown(self):
        os.close(self.db_fd)
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
        for fname in os.listdir(self.upload_dir):
            os.unlink(os.path.join(self.upload_dir, fname))
        os.rmdir(self.upload_dir)

    def test_f01_nowe_zapytanie_poprawne_i_bledne(self):
        # Przypadek błędny: brak wagi i miast
        resp_err = self.client.post(
            "/klient/zapytanie",
            data={
                "id_klienta": 1,
                "rodzaj_towaru": "",
                "waga_kg": "",
                "miejsce_zaladunku": "",
                "miejsce_rozladunku": "",
                "data_zaladunku": "",
            },
            follow_redirects=True,
        )
        self.assertIn("Wypełnij wszystkie wymagane pola trasa i ładunek.", resp_err.get_data(as_text=True))

        # Przypadek poprawny
        resp_ok = self.client.post(
            "/klient/zapytanie",
            data={
                "id_klienta": 1,
                "rodzaj_towaru": "Palety EUR – AGD",
                "waga_kg": "2500",
                "miejsce_zaladunku": "Olsztyn, 10-001",
                "miejsce_rozladunku": "Łódź, 90-001",
                "data_zaladunku": "2026-11-28",
                "uwagi": "Ostrożnie",
            },
            follow_redirects=True,
        )
        html = resp_ok.get_data(as_text=True)
        self.assertIn("ZL/2026/0004", html)
        self.assertIn("Palety EUR – AGD", html)

    def test_f01_wycena_i_oplacenie(self):
        # Błędna wycena (0 zł)
        resp_bad = self.client.post(
            "/spedytor/wycen/1",
            data={"id_spedytora": 3, "cena_netto": "0"},
            follow_redirects=True,
        )
        self.assertIn("Stawka netto musi być większa od 0 zł.", resp_bad.get_data(as_text=True))

        # Poprawna wycena
        resp_quote = self.client.post(
            "/spedytor/wycen/1",
            data={"id_spedytora": 3, "cena_netto": "1950.50"},
            follow_redirects=True,
        )
        self.assertIn("1950.50 zł netto", resp_quote.get_data(as_text=True))

        # Opłacenie wycenionego zlecenia przez klienta
        resp_pay = self.client.post(
            "/klient/oplac/1",
            data={"id_klienta": 1},
            follow_redirects=True,
        )
        self.assertIn("oznaczone jako Opłacone", resp_pay.get_data(as_text=True))

    def test_f02_planowanie_transportu_i_walidacja_przewoznika(self):
        # Zlecenie #2 ma wagę 11500 kg i status Opłacone.
        # Przewoźnik #5 ma ładowność 3500 kg -> odrzucenie z komunikatem z dokumentacji
        resp_err = self.client.post(
            "/spedytor/przydziel/2",
            data={"id_przewoznika": 5},
            follow_redirects=True,
        )
        self.assertIn(
            "Wybrany przewoźnik nie posiada wolnych pojazdów w danym terminie.",
            resp_err.get_data(as_text=True),
        )

        # Przewoźnik #4 ma ładowność 24000 kg i wolny termin 2026-11-22 -> przyjęcie
        resp_ok = self.client.post(
            "/spedytor/przydziel/2",
            data={"id_przewoznika": 4},
            follow_redirects=True,
        )
        self.assertIn("został przypisany do zlecenia ZL/2026/0002", resp_ok.get_data(as_text=True))

    def test_f03_sledzenie_statusu(self):
        resp = self.client.get("/sledzenie/?nr=ZL/2026/0003")
        html = resp.get_data(as_text=True)
        self.assertIn("ZL/2026/0003", html)
        self.assertIn("Autostrada A1 – okolice Torunia", html)

    def test_f04_upload_pod_i_rozliczenie(self):
        # Zły format pliku (.exe)
        resp_bad = self.client.post(
            "/przewoznik/pod/3",
            data={
                "przewoznik_id": 4,
                "plik_pod": (io.BytesIO(b"fake exe"), "wirus.exe"),
            },
            content_type="multipart/form-data",
            follow_redirects=True,
        )
        self.assertIn("Dopuszczalne formaty plików to JPG, PNG oraz PDF.", resp_bad.get_data(as_text=True))

        # Poprawny plik (.pdf)
        resp_ok = self.client.post(
            "/przewoznik/pod/3",
            data={
                "przewoznik_id": 4,
                "plik_pod": (io.BytesIO(b"%PDF-1.4 test pod"), "list_przewozowy_0003.pdf"),
            },
            content_type="multipart/form-data",
            follow_redirects=True,
        )
        self.assertIn("został pomyślnie przesłany", resp_ok.get_data(as_text=True))

        # Spedytor weryfikuje POD i rozlicza zlecenie
        resp_settle = self.client.post("/spedytor/rozlicz/3", follow_redirects=True)
        self.assertIn("zostało rozliczone i zamknięte", resp_settle.get_data(as_text=True))

    def test_trwalosc_danych_po_restarcie_aplikacji(self):
        # Zapis nowego zapytania w pierwszej instancji aplikacji
        self.client.post(
            "/klient/zapytanie",
            data={
                "id_klienta": 1,
                "rodzaj_towaru": "Test trwałości SQLite",
                "waga_kg": "900",
                "miejsce_zaladunku": "Warszawa",
                "miejsce_rozladunku": "Poznań",
                "data_zaladunku": "2026-12-01",
            },
        )
        # Utworzenie nowej instancji aplikacji wskazującej na ten sam plik bazy SQLite (symulacja restartu)
        restarted_app = create_app(
            {
                "TESTING": True,
                "DATABASE": self.db_path,
                "UPLOAD_FOLDER": self.upload_dir,
            }
        )
        restarted_client = restarted_app.test_client()
        resp = restarted_client.get("/sledzenie/?nr=ZL/2026/0004")
        self.assertIn("Test trwałości SQLite", resp.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
