PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Uzytkownicy (
    id_uzytkownika INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    haslo TEXT NOT NULL,
    typ_uzytkownika TEXT NOT NULL CHECK (typ_uzytkownika IN ('Klient', 'Spedytor', 'Przewoznik', 'Magazynier')),
    nazwa_wyswietlana TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Klienci (
    id_klienta INTEGER PRIMARY KEY,
    telefon TEXT NOT NULL,
    miasto TEXT NOT NULL,
    typ_klienta TEXT NOT NULL CHECK (typ_klienta IN ('Kontraktowy', 'Jednorazowy')),
    nazwa_podmiotu TEXT NOT NULL,
    nip TEXT,
    FOREIGN KEY (id_klienta) REFERENCES Uzytkownicy(id_uzytkownika) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Spedytorzy (
    id_spedytora INTEGER PRIMARY KEY,
    poziom_uprawnien INTEGER NOT NULL DEFAULT 1,
    region TEXT NOT NULL DEFAULT 'Polska Centralna',
    FOREIGN KEY (id_spedytora) REFERENCES Uzytkownicy(id_uzytkownika) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Przewoznici (
    id_przewoznika INTEGER PRIMARY KEY,
    nazwa_przewoznika TEXT NOT NULL,
    nr_rejestracyjny TEXT NOT NULL,
    ladownosc REAL NOT NULL CHECK (ladownosc > 0),
    FOREIGN KEY (id_przewoznika) REFERENCES Uzytkownicy(id_uzytkownika) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Zlecenia (
    id_zlecenia INTEGER PRIMARY KEY AUTOINCREMENT,
    id_klienta INTEGER NOT NULL,
    id_spedytora INTEGER,
    id_przewoznika INTEGER,
    nr_zlecenia TEXT NOT NULL UNIQUE,
    rodzaj_towaru TEXT NOT NULL,
    waga_kg REAL NOT NULL CHECK (waga_kg > 0),
    wymagana_chlodnia INTEGER NOT NULL DEFAULT 0 CHECK (wymagana_chlodnia IN (0, 1)),
    miejsce_zaladunku TEXT NOT NULL,
    miejsce_rozladunku TEXT NOT NULL,
    data_zaladunku TEXT NOT NULL,
    uwagi TEXT,
    status TEXT NOT NULL DEFAULT 'Nowe' CHECK (
        status IN ('Nowe', 'W wycenie', 'Wycenione', 'Opłacone', 'W transporcie', 'Zrealizowane', 'Anulowane', 'Odrzucone')
    ),
    cena_netto REAL,
    aktualna_lokalizacja TEXT NOT NULL DEFAULT 'Oczekuje na wycenę i akceptację',
    status_rampy TEXT NOT NULL DEFAULT 'Oczekuje na awizację',
    rampa_nr TEXT,
    utworzono_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    zaktualizowano_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_klienta) REFERENCES Klienci(id_klienta) ON DELETE NO ACTION,
    FOREIGN KEY (id_spedytora) REFERENCES Spedytorzy(id_spedytora) ON DELETE SET NULL,
    FOREIGN KEY (id_przewoznika) REFERENCES Przewoznici(id_przewoznika) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS DokumentyPOD (
    id_zlecenia INTEGER PRIMARY KEY,
    id_pliku TEXT NOT NULL UNIQUE,
    nazwa_pliku TEXT NOT NULL,
    sciezka_pliku TEXT NOT NULL,
    data_wgrania TEXT NOT NULL,
    zweryfikowany INTEGER NOT NULL DEFAULT 0 CHECK (zweryfikowany IN (0, 1)),
    FOREIGN KEY (id_zlecenia) REFERENCES Zlecenia(id_zlecenia) ON DELETE CASCADE
);
