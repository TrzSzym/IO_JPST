# Dobór i uzasadnienie technologii – System Spedycyjny „NaWczoraj”

## Wybrany stos technologiczny (MVP v1.0)

| Obszar | Wybrana technologia | Wersja | Rola w projekcie |
| :--- | :--- | :--- | :--- |
| **Widoki (Frontend)** | HTML5, CSS3, Jinja2 | HTML5 / CSS3 / Jinja2 3.1+ | Struktura interfejsu użytkownika (W01–W04), formularze, tabele zleceń oraz prezentacja komunikatów błędów i sukcesu. |
| **Serwer (Backend)** | Python + Flask | Python 3.11+ / Flask 3.0+ | Obsługa żądań HTTP (GET/POST), routing w podziale na Blueprinty MVC, walidacja danych po stronie serwera i obsługa plików POD. |
| **Baza danych** | SQLite (`sqlite3`) | SQLite 3 | Trwały zapis użytkowników, zleceń i metadanych dokumentów POD w lokalnym pliku `nawczoraj.db` z obsługą kluczy obcych (`PRAGMA foreign_keys = ON`). |
| **Praca zespołowa** | VS Code, Git, GitHub | Git 2.x | Wspólna edycja kodu, kontrola wersji oraz historia commitów obu członków zespołu. |

## Uzasadnienie wyboru

Do realizacji wersji MVP v1.0 systemu spedycyjnego „NaWczoraj” wybrano lekki stos oparty na języku **Python 3**, mikroframeworku **Flask**, szablonach **HTML/CSS (Jinja2)** oraz relacyjnej bazie **SQLite**. Zestaw ten pozwala uruchomić aplikację lokalnie na dowolnym systemie operacyjnym (Windows, Linux, macOS) bez konieczności instalowania zewnętrznych serwerów bazodanowych ani płatnych usług chmurowych. Framework Flask umożliwia przejrzyste rozdzielenie warstw **MVC** dzięki mechanizmowi *Blueprint* dla kontrolerów oraz prostemu silnikowi szablonów dla widoków W01–W04. Wbudowany moduł `sqlite3` gwarantuje trwałość danych po restarcie serwera, pełne wsparcie dla zapytań parametryzowanych oraz egzekwowanie więzów integralności referencyjnej zgodnych ze schematem relacyjnym z dokumentacji PSI. Dodatkowo natywna obsługa przesyłania plików we Flasku ułatwia realizację funkcji wgrywania i walidacji dokumentów przewozowych POD (JPG, PNG, PDF). Wybrany stos jest dobrze znany obu członkom zespołu, co minimalizuje ryzyko techniczne i pozwala skupić się na poprawności logiki biznesowej spedycji.
