# Dziennik Inżynierii Promptów i MVC – System Spedycyjny „NaWczoraj” (v1.0)

## Zadanie 1: Doprecyzowanie polecenia (od ogólnego do precyzyjnego)

* **Prompt ogólny (odrzucony):**  
  *„Zrób aplikację spedycyjną NaWczoraj we Flasku.”*  
  *(Brak podziału na role, schematu bazy danych, reguł walidacji oraz rozdzielenia warstw MVC).*

* **Prompt precyzyjny (szablon P1 – Plan MVP i mapa MVC):**  
  > Pomóż nam zaplanować MVP 1.0 projektu **System spedycyjny „NaWczoraj”**.  
  > **Cel użytkownika:** Umożliwienie Klientowi złożenia zapytania o transport i opłacenia wyceny, Spedytorowi wyceny zlecenia oraz przydzielenia wolnego przewoźnika, Przewoźnikowi wgrania dokumentu POD, a każdemu uczestnikowi śledzenia statusu przesyłki po numerze zlecenia.  
  > **Stos:** Python 3, Flask, SQLite (`sqlite3` z `PRAGMA foreign_keys = ON`), HTML5/CSS3 (Jinja2).  
  > **Zakres:** F01 (UC4/UC10 – zapytanie, wycena i opłacenie zlecenia), F02 (UC3/UC13 – planowanie transportu i przydział przewoźnika), F03 (UC2 – śledzenie statusu po `nr_zlecenia`), F04 (UC9/UC12 – wgrywanie pliku POD w formacie JPG/PNG/PDF oraz rozliczenie zlecenia), W04 (UC8 – obsługa rampy magazynowej). Wykluczenia do v2: protokoły szkód (UC1) oraz panel zarządczy właściciela (UC14, UC16).  
  > **Widoki i dane:** W01 Panel Klienta, W02 Pulpit Spedytora, W03 Panel Przewoźnika, W04 Panel Magazyniera, widok śledzenia F03; 6 tabel SQLite (`Uzytkownicy`, `Klienci`, `Spedytorzy`, `Przewoznici`, `Zlecenia`, `DokumentyPOD`).  
  > **Wynik:** Przygotuj podział odpowiedzialności na Model (`models/`), Widok (`templates/`) i Kontroler (`controllers/`) wraz z mapą plików i kryteriami poprawności.

---

## Zadanie 2: Szkielet MVC i pojedyncze funkcje (P2 i P3)

### Szablon P2 – Działający szkielet aplikacji MVC
> Wykonaj pierwszy etap zaakceptowanego planu MVP dla projektu **System spedycyjny „NaWczoraj”**.  
> **Technologie:** Python 3, Flask, SQLite (`sqlite3`), HTML5/CSS3.  
> **Zadanie:** Wyodrębnij warstwę Modelu (`db.py`, `schema.sql`, `seed.sql`, `models/`), Widoku (`templates/base.html` oraz szablony W01–W04) i Kontrolera (`controllers/*.py` jako Blueprinty Flask rejestrowane w `app.py`). Przygotuj pierwszą działającą ścieżkę od adresu `/klient` przez model `pobierz_zlecenia()` do szablonu `klient/panel.html`.  
> **Kryterium:** Aplikacja uruchamia się poleceniem `flask --app app run`, inicjalizuje bazę SQLite z kluczami obcymi i wyświetla dane startowe.

### Szablon P3 – Implementacja funkcji F01–F04 z walidacjami
> W aktualnym szkielecie MVC wykonaj kolejno funkcje **F01, F02, F03 oraz F04**:  
> - **F01 (W01/W02):** Klient składa zapytanie (`utworz_zapytanie`), Spedytor wprowadza stawkę netto (`wycen_zlecenie`), Klient akceptuje i opłaca (`oplac_zlecenie`). Przypadek błędny: puste pola trasy/ładunku → komunikat *„Wypełnij wszystkie wymagane pola trasa i ładunek.”*.  
> - **F02 (W02):** Spedytor przypisuje przewoźnika do zlecenia o statusie `Opłacone` (`przydziel_przewoznika`). Reguły modelu: sprawdzenie ładowności (`ladownosc >= waga_kg`) oraz braku kolizji w dacie `data_zaladunku`. Przypadek błędny: brak wolnych mocy/ładowności → komunikat *„Wybrany przewoźnik nie posiada wolnych pojazdów w danym terminie.”*.  
> - **F03 (`/sledzenie`):** Wyszukiwanie zlecenia po unikalnym `nr_zlecenia` (`znajdz_po_numerze`) i prezentacja osi statusów oraz aktualnej lokalizacji.  
> - **F04 (W03/W02):** Przewoźnik wgrywa plik POD (`zapisz_dokument_pod`). Przypadek błędny: niedozwolone rozszerzenie → komunikat *„Dopuszczalne formaty plików to JPG, PNG oraz PDF.”*. Spedytor weryfikuje POD i zamyka zlecenie (`zweryfikuj_i_rozlicz_zlecenie` → status `Zrealizowane`).  
> **Ograniczenia:** Używaj wyłącznie zapytań parametryzowanych SQL i zachowaj separację MVC.

---

## Zadanie 3: Próba, diagnoza i poprawka przed odbiorem (P4)

### Szablon P4 – Przegląd i wykryta niezgodność w szablonie widoku śledzenia
> **Aktualne pliki:** `templates/sledzenie/status.html`, `controllers/sledzenie.py`, `models/zlecenie.py`.  
> **Sposób uruchomienia:** `python3 -m flask --app app run` (Python 3.11, Flask 3.0, Jinja2 3.1).  
> **Kroki odtworzenia:** Otwarcie widoku `/sledzenie?nr=ZL/2026/0003` w celu sprawdzenia osi postępu etapów realizacji zlecenia.  
> **Oczekiwane działanie:** Wyrenderowanie 5-etapowej osi postępu (`Nowe` → `Wycenione` → `Opłacone` → `W transporcie` → `Zrealizowane`) z wyróżnieniem bieżącego oraz ukończonych etapów.  
> **Faktyczny wynik i komunikat:** Błąd składni silnika szablonów `jinja2.exceptions.TemplateSyntaxError: expected token 'end of statement block', got 'if'` spowodowany użyciem zagnieżdżonego wyrażenia warunkowego `if ... else` wewnątrz klauzuli `{% elif ... %}`.  
> **Przyczyna i najmniejsza poprawka:** Zastąpienie zagnieżdżonego wyrażenia warunkowego koniunkcją logiczną `{% elif wynik['status'] in etapy and etapy.index(etap) < etapy.index(wynik['status']) %}` w `templates/sledzenie/status.html`.  
> **Ponowne sprawdzenie:** Wszystkie 6 szablonów Jinja2 kompilują się i renderują poprawnie z danymi z bazy SQLite, a funkcje F01–F04 działają bez regresji.
