# Dokumentacja Testów Wersji v1.0.0 – System Spedycyjny „NaWczoraj”

## 1. Zestawienie scenariuszy testowych (przypadki poprawne, błędne i trwałość danych)

| ID Testu | Funkcja / Widok | Dane wejściowe i kroki | Oczekiwany wynik | Status |
| :--- | :--- | :--- | :--- | :--- |
| **T01** | F01 / W01 (poprawny) | W formularzu W01 wpisać: towar `Palety EUR – AGD`, waga `2500`, załadunek `Olsztyn, 10-001`, rozładunek `Łódź, 90-001`, data `2026-11-28`, wysłać formularz. | Utworzenie rekordu `ZL/2026/0004` ze statusem `Nowe` w SQLite i wyświetlenie go na liście zleceń klienta. | **działa** |
| **T02** | F01 / W01 (błędny) | W formularzu W01 pozostawić puste pola trasy i wagi i kliknąć *„Wyślij zapytanie do wyceny”*. | Odrzucenie zapisu i wyświetlenie komunikatu: *„Wypełnij wszystkie wymagane pola trasa i ładunek.”* | **działa** |
| **T03** | F01 / W02 & W01 (wycena i płatność) | W W02 wpisać stawkę `0` (błąd), następnie `1950.50` zł dla `ZL/2026/0001`, a w W01 kliknąć *„Akceptuj (faktura 14 dni)”*. | Odrzucenie stawki `0`, a po poprawnej wycenie i akceptacji zmiana statusu kolejno na `Wycenione` oraz `Opłacone`. | **działa** |
| **T04** | F02 / W02 (błędny – brak wolnych mocy) | Dla zlecenia `ZL/2026/0002` (`Opłacone`, waga `11 500 kg`) wybrać przewoźnika *Szybki-Trans Bus* (ładowność `3 500 kg`) i kliknąć *„Zleć transport (F02)”*. | Odrzucenie przydziału i wyświetlenie komunikatu: *„Wybrany przewoźnik nie posiada wolnych pojazdów w danym terminie.”* | **działa** |
| **T05** | F02 / W02 (poprawny) | Dla zlecenia `ZL/2026/0002` wybrać przewoźnika *Trans-Pol Sp. z o.o.* (ładowność `24 000 kg`, wolny termin `2026-11-22`). | Przypisanie przewoźnika do zlecenia i zmiana statusu na `W transporcie`. | **działa** |
| **T06** | F03 / Śledzenie | Wejść na `/sledzenie` i wyszukać numer `ZL/2026/0003`. | Wyświetlenie osi etapów, statusu `W transporcie` oraz bieżącej lokalizacji (*Autostrada A1 – okolice Torunia*). | **działa** |
| **T07** | F04 / W03 (błędny format pliku) | W W03 dla zlecenia `ZL/2026/0003` spróbować wgrać plik `wirus.exe`. | Odrzucenie pliku i wyświetlenie komunikatu: *„Dopuszczalne formaty plików to JPG, PNG oraz PDF.”* | **działa** |
| **T08** | F04 / W03 & W02 (poprawny POD i rozliczenie) | W W03 wgrać plik `list_przewozowy_0003.pdf`, a następnie w W02 kliknąć *„Zweryfikuj POD i rozlicz (F04)”*. | Zapis pliku w `static/uploads/pod/`, rejestracja w tabeli `DokumentyPOD`, weryfikacja i zmiana statusu zlecenia na `Zrealizowane`. | **działa** |
| **T09** | W04 / Rampa magazynowa | W widoku W04 wybrać `Rampa 1 – Centrala Łódź` oraz operację *„Potwierdzenie załadunku i wydania”* dla `ZL/2026/0002`. | Aktualizacja statusu rampy oraz pozycji przesyłki widocznej w module śledzenia F03. | **działa** |
| **T10** | Trwałość danych po restarcie | Dodać nowe zapytanie w W01, zatrzymać serwer (`Ctrl+C`), uruchomić ponownie `flask --app app run` i sprawdzić listę zleceń. | Nowo dodane zlecenie oraz wcześniejsze rekordy pozostają zachowane w pliku bazy `nawczoraj.db`. | **działa** |

---

## 2. Weryfikacja integralności bazy danych i kodu

* Potwierdzono wymuszanie więzów integralności referencyjnej w SQLite (`PRAGMA foreign_keys = ON;` – próba wstawienia rekordu z nieistniejącym `id_klienta` kończy się wyjątkiem `sqlite3.IntegrityError`).
* Potwierdzono poprawność kompilacji wszystkich modułów Python (`app.py`, `db.py`, `models/*`, `controllers/*`, `tests/test_mvp.py`) oraz renderowania wszystkich 6 szablonów HTML Jinja2.
* Kod automatycznych testów znajduje się w pliku `tests/test_mvp.py` i można go uruchomić po instalacji zależności z `requirements.txt` poleceniem:
  ```bash
  python -m unittest discover -s tests -v
  ```
