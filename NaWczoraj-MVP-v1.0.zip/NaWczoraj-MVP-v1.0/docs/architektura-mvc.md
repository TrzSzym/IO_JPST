# Architektura MVC – System Spedycyjny „NaWczoraj” (v1.0)

## 1. Podział odpowiedzialności w architekturze MVC

Aplikacja została uporządkowana zgodnie z wzorcem **Model–Widok–Kontroler (MVC)**:

* **Model (`models/`, `db.py`, `schema.sql`)** – odpowiada za połączenie z bazą SQLite, egzekwowanie kluczy obcych (`PRAGMA foreign_keys = ON`), wykonywanie zapytań parametryzowanych oraz realizację reguł biznesowych i walidacji (m.in. kompletność trasy i ładunku, dodatnia kwota wyceny, dostępność i ładowność przewoźnika w terminie, weryfikacja rozszerzeń plików POD).
* **Widok (`templates/`, `static/css/style.css`)** – odpowiada wyłącznie za warstwę prezentacji: nawigację między rolami (W01–W04, F03), formularze wejściowe, tabele zleceń, oś postępu realizacji oraz wyświetlanie komunikatów `flash` (sukcesu i błędów). Widoki nie zawierają zapytań SQL ani logiki biznesowej.
* **Kontroler (`controllers/*.py`, `app.py`)** – odbiera żądania HTTP (`GET` i `POST`), pobiera parametry formularzy lub pliki, wywołuje odpowiednie funkcje warstwy Modelu i decyduje o przekierowaniu (`redirect`) lub wyrenderowaniu szablonu (`render_template`).

---

## 2. Mapa plików projektu

| Plik / Katalog | Warstwa MVC | Odpowiedzialność |
| :--- | :--- | :--- |
| `app.py` | Konfiguracja / Kontroler główny | Tworzenie instancji aplikacji Flask (`create_app`), rejestracja Blueprintów, komenda CLI `init-db`. |
| `db.py` | Model (warstwa danych) | Zarządzanie połączeniem `sqlite3` w kontekście żądania, włączanie `PRAGMA foreign_keys = ON`, inicjalizacja bazy. |
| `schema.sql`, `seed.sql` | Model (schemat i dane) | Definicja 6 tabel relacyjnych (`Uzytkownicy`, `Klienci`, `Spedytorzy`, `Przewoznici`, `Zlecenia`, `DokumentyPOD`) oraz dane demonstracyjne. |
| `models/uzytkownik.py` | Model | Pobieranie list klientów, spedytorów i przewoźników na potrzeby widoków i walidacji. |
| `models/zlecenie.py` | Model | Logika funkcji **F01** (`utworz_zapytanie`, `wycen_zlecenie`, `oplac_zlecenie`), **F02** (`przydziel_przewoznika`), **F03** (`znajdz_po_numerze`, `aktualizuj_lokalizacje`) oraz **W04** (`obsluz_rampe`). |
| `models/dokument_pod.py` | Model | Logika funkcji **F04** (`zapisz_dokument_pod` z walidacją rozszerzeń JPG/PNG/PDF oraz `zweryfikuj_i_rozlicz_zlecenie`). |
| `controllers/klient.py` | Kontroler | Obsługa tras `/klient` dla widoku **W01** (składanie zapytania, opłacanie wyceny). |
| `controllers/spedytor.py` | Kontroler | Obsługa tras `/spedytor` dla widoku **W02** (wycena zlecenia, przydział przewoźnika, weryfikacja POD i rozliczenie). |
| `controllers/przewoznik.py` | Kontroler | Obsługa tras `/przewoznik` dla widoku **W03** (aktualizacja lokalizacji, wgrywanie pliku POD). |
| `controllers/magazynier.py` | Kontroler | Obsługa tras `/magazynier` dla widoku **W04** (obsługa przyjęć i wydań towaru na rampie). |
| `controllers/sledzenie.py` | Kontroler | Obsługa tras `/sledzenie` dla funkcji **F03** (wyszukiwanie i podgląd statusu po `nr_zlecenia`). |
| `templates/base.html` | Widok | Szablon bazowy z paskiem przełączania ról i obsługą komunikatów walidacji. |
| `templates/klient/panel.html` | Widok (**W01**) | Formularz nowego zapytania o transport oraz lista zleceń klienta. |
| `templates/spedytor/pulpit.html` | Widok (**W02**) | Pulpit wycen, przypisywania przewoźników oraz rozliczania dokumentów POD. |
| `templates/przewoznik/panel.html` | Widok (**W03**) | Lista przydzielonych tras, aktualizacja lokalizacji i formularz wysyłki pliku POD. |
| `templates/magazynier/rampa.html` | Widok (**W04**) | Panel obsługi ramp magazynowych (przyjęcia i załadunki). |
| `templates/sledzenie/status.html` | Widok (**F03**) | Wyszukiwarka po numerze zlecenia oraz oś postępu realizacji. |

---

## 3. Przepływ żądania na przykładzie funkcji F02 (Planowanie transportu)

1. **Widok (`templates/spedytor/pulpit.html`)**: Spedytor wybiera z listy rozwijanej przewoźnika dla zlecenia o statusie `Opłacone` i wysyła formularz `POST /spedytor/przydziel/<id_zlecenia>`.
2. **Kontroler (`controllers/spedytor.py`)**: Funkcja `przydziel(id_zlecenia)` odczytuje `id_przewoznika` z `request.form` i wywołuje `przydziel_przewoznika(id_zlecenia, id_przewoznika)`.
3. **Model (`models/zlecenie.py`)**: Funkcja pobiera zlecenie oraz przewoźnika z SQLite, sprawdza czy `status == 'Opłacone'`, czy ładowność pojazdu jest wystarczająca (`ladownosc >= waga_kg`) oraz czy przewoźnik nie ma kolizji w `data_zaladunku`. W razie niespełnienia warunku zwraca komunikat błędu; przy poprawnych danych aktualizuje rekord w tabeli `Zlecenia` (`status = 'W transporcie'`).
4. **Kontroler → Widok**: Kontroler zapisuje komunikat w `flash(...)` i wykonuje przekierowanie `redirect(url_for("spedytor.pulpit"))`, po czym szablon prezentuje zaktualizowany stan zlecenia.
