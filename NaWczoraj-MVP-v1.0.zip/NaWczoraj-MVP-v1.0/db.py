import os
import sqlite3
from flask import current_app, g


def get_db() -> sqlite3.Connection:
    """Zwraca połączenie z bazą SQLite dla bieżącego żądania z włączonymi kluczami obcymi."""
    if "db" not in g:
        db_path = current_app.config["DATABASE"]
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        g.db = conn
    return g.db


def close_db(e=None) -> None:
    """Zamyka połączenie z bazą danych po zakończeniu obsługi żądania."""
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(seed: bool = True) -> None:
    """Tworzy strukturę tabel na podstawie schema.sql oraz opcjonalnie ładuje dane startowe."""
    db = get_db()
    root_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(root_dir, "schema.sql"), "r", encoding="utf-8") as f:
        db.executescript(f.read())
    if seed:
        with open(os.path.join(root_dir, "seed.sql"), "r", encoding="utf-8") as f:
            db.executescript(f.read())
    db.commit()


def ensure_db_initialized(app) -> None:
    """Automatycznie inicjalizuje bazę danych przy pierwszym uruchomieniu, jeśli plik jeszcze nie istnieje."""
    db_path = app.config["DATABASE"]
    if not os.path.exists(db_path):
        with app.app_context():
            init_db(seed=True)
