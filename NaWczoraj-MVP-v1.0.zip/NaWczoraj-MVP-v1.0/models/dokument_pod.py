import os
import uuid
from datetime import datetime
from werkzeug.utils import secure_filename
from db import get_db

DOZWOLONE_ROZSZERZENIA = {"jpg", "png", "pdf"}


def czy_dozwolony_format(filename: str) -> bool:
    if not filename or "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in DOZWOLONE_ROZSZERZENIA


def zapisz_dokument_pod(id_zlecenia: int, plik, upload_folder: str):
    """
    F04 (UC9): Wgrywa dokument przewozowy POD (JPG, PNG lub PDF) dla zlecenia w transporcie.
    """
    if plik is None or not getattr(plik, "filename", ""):
        return False, "Dopuszczalne formaty plików to JPG, PNG oraz PDF."

    if not czy_dozwolony_format(plik.filename):
        return False, "Dopuszczalne formaty plików to JPG, PNG oraz PDF."

    db = get_db()
    zlecenie = db.execute("SELECT * FROM Zlecenia WHERE id_zlecenia = ?", (id_zlecenia,)).fetchone()
    if zlecenie is None:
        return False, "Nie znaleziono zlecenia."

    if zlecenie["status"] not in ("W transporcie", "Zrealizowane"):
        return False, "Dokument POD można wgrać tylko dla zlecenia będącego w transporcie."

    os.makedirs(upload_folder, exist_ok=True)
    bezpieczna_nazwa = secure_filename(plik.filename)
    ext = bezpieczna_nazwa.rsplit(".", 1)[1].lower()
    id_pliku = f"POD_{zlecenie['id_zlecenia']}_{uuid.uuid4().hex[:8]}.{ext}"
    pelna_sciezka = os.path.join(upload_folder, id_pliku)
    plik.save(pelna_sciezka)

    wzgledna_sciezka = f"uploads/pod/{id_pliku}"
    teraz = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    db.execute(
        """
        INSERT INTO DokumentyPOD (id_zlecenia, id_pliku, nazwa_pliku, sciezka_pliku, data_wgrania, zweryfikowany)
        VALUES (?, ?, ?, ?, ?, 0)
        ON CONFLICT(id_zlecenia) DO UPDATE SET
            id_pliku = excluded.id_pliku,
            nazwa_pliku = excluded.nazwa_pliku,
            sciezka_pliku = excluded.sciezka_pliku,
            data_wgrania = excluded.data_wgrania,
            zweryfikowany = 0
        """,
        (id_zlecenia, id_pliku, bezpieczna_nazwa, wzgledna_sciezka, teraz),
    )

    db.execute(
        """
        UPDATE Zlecenia
        SET aktualna_lokalizacja = ?,
            zaktualizowano_at = ?
        WHERE id_zlecenia = ?
        """,
        (f"Dostarczono do {zlecenie['miejsce_rozladunku']} – wgrano dokument POD ({bezpieczna_nazwa})", teraz, id_zlecenia),
    )
    db.commit()
    return True, f"Dokument POD '{bezpieczna_nazwa}' został pomyślnie przesłany dla zlecenia {zlecenie['nr_zlecenia']}."


def zweryfikuj_i_rozlicz_zlecenie(id_zlecenia: int):
    """
    F04 (UC12): Spedytor weryfikuje dokument POD i zamyka/rozlicza zlecenie (status -> 'Zrealizowane').
    """
    db = get_db()
    zlecenie = db.execute("SELECT * FROM Zlecenia WHERE id_zlecenia = ?", (id_zlecenia,)).fetchone()
    if zlecenie is None:
        return False, "Nie znaleziono zlecenia."

    pod = db.execute("SELECT * FROM DokumentyPOD WHERE id_zlecenia = ?", (id_zlecenia,)).fetchone()
    if pod is None:
        return False, "Brak wgranego dokumentu POD – nie można zamknąć i rozliczyć zlecenia."

    teraz = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    db.execute("UPDATE DokumentyPOD SET zweryfikowany = 1 WHERE id_zlecenia = ?", (id_zlecenia,))
    db.execute(
        """
        UPDATE Zlecenia
        SET status = 'Zrealizowane',
            aktualna_lokalizacja = 'Zrealizowane i rozliczone (POD zweryfikowany)',
            status_rampy = 'Zakończono obsługę',
            zaktualizowano_at = ?
        WHERE id_zlecenia = ?
        """,
        (teraz, id_zlecenia),
    )
    db.commit()
    return True, f"Dokument POD zweryfikowany. Zlecenie {zlecenie['nr_zlecenia']} zostało rozliczone i zamknięte."
