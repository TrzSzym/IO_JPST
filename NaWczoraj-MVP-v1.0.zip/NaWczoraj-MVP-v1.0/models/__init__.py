# Warstwa Modelu (M) - System Spedycyjny NaWczoraj
