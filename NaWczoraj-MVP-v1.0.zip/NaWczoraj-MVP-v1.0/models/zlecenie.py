from datetime import datetime
from db import get_db


def generuj_numer_zlecenia(db) -> str:
    """Generuje kolejny unikalny numer zlecenia w formacie ZL/RRRR/XXXX."""
    rok = datetime.now().year
    row = db.execute("SELECT COALESCE(MAX(id_zlecenia), 0) AS max_id FROM Zlecenia").fetchone()
    kolejny = (row["max_id"] or 0) + 1
    return f"ZL/{rok}/{kolejny:04d}"


def utworz_zapytanie(
    id_klienta: int,
    rodzaj_towaru: str,
    waga_raw: str,
    wymagana_chlodnia: bool,
    miejsce_zaladunku: str,
    miejsce_rozladunku: str,
    data_zaladunku: str,
    uwagi: str = "",
):
    """
    F01 (UC4): Tworzy nowe zapytanie o zlecenie transportowe.
    Waliduje wymagane pola trasy i ładunku zgodnie z dokumentacją widoków W01.
    """
    rodzaj_towaru = (rodzaj_towaru or "").strip()
    miejsce_zaladunku = (miejsce_zaladunku or "").strip()
    miejsce_rozladunku = (miejsce_rozladunku or "").strip()
    data_zaladunku = (data_zaladunku or "").strip()
    uwagi = (uwagi or "").strip()

    try:
        waga_kg = float(str(waga_raw).replace(",", "."))
    except (ValueError, TypeError):
        waga_kg = 0.0

    if not rodzaj_towaru or not miejsce_zaladunku or not miejsce_rozladunku or not data_zaladunku or waga_kg <= 0:
        return False, "Wypełnij wszystkie wymagane pola trasa i ładunek.", None

    db = get_db()
    klient = db.execute("SELECT id_klienta FROM Klienci WHERE id_klienta = ?", (id_klienta,)).fetchone()
    if klient is None:
        return False, "Wybrany klient nie istnieje w bazie danych.", None

    nr_zlecenia = generuj_numer_zlecenia(db)
    teraz = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        """
        INSERT INTO Zlecenia (
            id_klienta, nr_zlecenia, rodzaj_towaru, waga_kg, wymagana_chlodnia,
            miejsce_zaladunku, miejsce_rozladunku, data_zaladunku, uwagi,
            status, aktualna_lokalizacja, status_rampy, utworzono_at, zaktualizowano_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Nowe', 'Oczekuje na wycenę spedytora', 'Oczekuje na awizację', ?, ?)
        """,
        (
            id_klienta,
            nr_zlecenia,
            rodzaj_towaru,
            waga_kg,
            1 if wymagana_chlodnia else 0,
            miejsce_zaladunku,
            miejsce_rozladunku,
            data_zaladunku,
            uwagi,
            teraz,
            teraz,
        ),
    )
    db.commit()
    return True, f"Zapytanie {nr_zlecenia} zostało pomyślnie przesłane do wyceny.", nr_zlecenia


def wycen_zlecenie(id_zlecenia: int, id_spedytora: int, cena_netto_raw: str):
    """
    F01 (UC10): Spedytor wycenia zlecenie na podstawie stawek rynkowych i marży.
    Warunek poprawności: kompletnie wypełniona trasa, stawka > 0 zł.
    """
    try:
        cena_netto = round(float(str(cena_netto_raw).replace(",", ".")), 2)
    except (ValueError, TypeError):
        cena_netto = 0.0

    if cena_netto <= 0:
        return False, "Stawka netto musi być większa od 0 zł."

    db = get_db()
    zlecenie = db.execute("SELECT * FROM Zlecenia WHERE id_zlecenia = ?", (id_zlecenia,)).fetchone()
    if zlecenie is None:
        return False, "Nie znaleziono wskazanego zlecenia."

    if zlecenie["status"] not in ("Nowe", "W wycenie", "Wycenione"):
        return False, f"Zlecenie {zlecenie['nr_zlecenia']} ma status '{zlecenie['status']}' i nie podlega ponownej wycenie."

    if not zlecenie["miejsce_zaladunku"] or not zlecenie["miejsce_rozladunku"]:
        return False, "Wypełnij wszystkie wymagane pola trasa i ładunek."

    teraz = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        """
        UPDATE Zlecenia
        SET id_spedytora = ?,
            cena_netto = ?,
            status = 'Wycenione',
            aktualna_lokalizacja = 'Wycena gotowa – oczekuje na akceptację i płatność klienta',
            zaktualizowano_at = ?
        WHERE id_zlecenia = ?
        """,
        (id_spedytora, cena_netto, teraz, id_zlecenia),
    )
    db.commit()
    return True, f"Zlecenie {zlecenie['nr_zlecenia']} zostało wycenione na kwotę {cena_netto:.2f} zł netto."


def oplac_zlecenie(id_zlecenia: int):
    """
    UC5 / UC7: Akceptacja wyceny i rejestracja płatności (przedpłata lub faktura terminowa).
    Zmienia status na 'Opłacone', umożliwiając planowanie transportu w F02.
    """
    db = get_db()
    zlecenie = db.execute("SELECT * FROM Zlecenia WHERE id_zlecenia = ?", (id_zlecenia,)).fetchone()
    if zlecenie is None:
        return False, "Nie znaleziono zlecenia."

    if zlecenie["status"] != "Wycenione" or not zlecenie["cena_netto"] or zlecenie["cena_netto"] <= 0:
        return False, "Opłacić można wyłącznie zlecenie posiadające zatwierdzoną wycenę."

    teraz = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        """
        UPDATE Zlecenia
        SET status = 'Opłacone',
            aktualna_lokalizacja = 'Opłacone – oczekuje na przydział przewoźnika',
            zaktualizowano_at = ?
        WHERE id_zlecenia = ?
        """,
        (teraz, id_zlecenia),
    )
    db.commit()
    return True, f"Zlecenie {zlecenie['nr_zlecenia']} zostało zaakceptowane i oznaczone jako Opłacone."


def przydziel_przewoznika(id_zlecenia: int, id_przewoznika: int):
    """
    F02 (UC3 / UC13): Planowanie i zlecanie transportu.
    Warunki:
    1. Zlecenie musi mieć status 'Opłacone'.
    2. Wybrany przewoźnik musi mieć wystarczającą ładowność i nie może mieć kolizji innego transportu w tym samym dniu.
    """
    db = get_db()
    zlecenie = db.execute("SELECT * FROM Zlecenia WHERE id_zlecenia = ?", (id_zlecenia,)).fetchone()
    if zlecenie is None:
        return False, "Nie znaleziono zlecenia."

    if zlecenie["status"] != "Opłacone":
        return False, "Planowanie transportu jest możliwe wyłącznie dla zleceń o statusie 'Opłacone'."

    przewoznik = db.execute("SELECT * FROM Przewoznici WHERE id_przewoznika = ?", (id_przewoznika,)).fetchone()
    if przewoznik is None:
        return False, "Wybrany przewoźnik nie istnieje."

    # Sprawdzenie ładowności oraz dostępności pojazdu w dniu załadunku
    kolizja = db.execute(
        """
        SELECT id_zlecenia FROM Zlecenia
        WHERE id_przewoznika = ?
          AND data_zaladunku = ?
          AND status = 'W transporcie'
          AND id_zlecenia != ?
        """,
        (id_przewoznika, zlecenie["data_zaladunku"], id_zlecenia),
    ).fetchone()

    if kolizja is not None or float(przewoznik["ladownosc"]) < float(zlecenie["waga_kg"]):
        return False, "Wybrany przewoźnik nie posiada wolnych pojazdów w danym terminie."

    teraz = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lokalizacja = f"Przydzielono przewoźnika ({przewoznik['nr_rejestracyjny']}) – oczekiwanie na załadunek w {zlecenie['miejsce_zaladunku']}"
    db.execute(
        """
        UPDATE Zlecenia
        SET id_przewoznika = ?,
            status = 'W transporcie',
            aktualna_lokalizacja = ?,
            status_rampy = 'Awizowane do załadunku',
            zaktualizowano_at = ?
        WHERE id_zlecenia = ?
        """,
        (id_przewoznika, lokalizacja, teraz, id_zlecenia),
    )
    db.commit()
    return True, f"Przewoźnik {przewoznik['nazwa_przewoznika']} został przypisany do zlecenia {zlecenie['nr_zlecenia']}."


def aktualizuj_lokalizacje(id_zlecenia: int, nowa_lokalizacja: str):
    """F03 / W03: Aktualizacja bieżącej lokalizacji i postępu trasy przez przewoźnika."""
    nowa_lokalizacja = (nowa_lokalizacja or "").strip()
    if not nowa_lokalizacja:
        return False, "Podaj aktualną lokalizację lub etap przewozu."

    db = get_db()
    zlecenie = db.execute("SELECT * FROM Zlecenia WHERE id_zlecenia = ?", (id_zlecenia,)).fetchone()
    if zlecenie is None:
        return False, "Nie znaleziono zlecenia."

    teraz = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        """
        UPDATE Zlecenia
        SET aktualna_lokalizacja = ?,
            zaktualizowano_at = ?
        WHERE id_zlecenia = ?
        """,
        (nowa_lokalizacja, teraz, id_zlecenia),
    )
    db.commit()
    return True, f"Zaktualizowano pozycję zlecenia {zlecenie['nr_zlecenia']}."


def obsluz_rampe(id_zlecenia: int, rampa_nr: str, operacja: str):
    """
    W04 (UC8): Obsługa przyjęć i wydań towaru na rampie magazynowej.
    """
    rampa_nr = (rampa_nr or "").strip() or "Rampa 1 (Łódź)"
    db = get_db()
    zlecenie = db.execute("SELECT * FROM Zlecenia WHERE id_zlecenia = ?", (id_zlecenia,)).fetchone()
    if zlecenie is None:
        return False, "Nie znaleziono zlecenia."

    teraz = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if operacja == "przyjecie":
        status_rampy = f"Przyjęto na magazyn ({rampa_nr})"
        lokalizacja = f"Magazyn – {rampa_nr} (towar przyjęty i zweryfikowany)"
    else:
        status_rampy = f"Załadowano i wydano ({rampa_nr})"
        lokalizacja = f"Opuszczono rampę {rampa_nr} – pojazd w drodze do {zlecenie['miejsce_rozladunku']}"

    db.execute(
        """
        UPDATE Zlecenia
        SET rampa_nr = ?,
            status_rampy = ?,
            aktualna_lokalizacja = ?,
            zaktualizowano_at = ?
        WHERE id_zlecenia = ?
        """,
        (rampa_nr, status_rampy, lokalizacja, teraz, id_zlecenia),
    )
    db.commit()
    return True, f"Zarejestrowano operację magazynową dla zlecenia {zlecenie['nr_zlecenia']} ({status_rampy})."


def pobierz_zlecenia(id_klienta=None, id_przewoznika=None):
    """Pobiera listę zleceń wraz z powiązanymi danymi klienta, spedytora, przewoźnika oraz POD."""
    db = get_db()
    query = """
        SELECT
            z.*,
            k.nazwa_podmiotu AS klient_nazwa,
            k.typ_klienta AS klient_typ,
            us.nazwa_wyswietlana AS spedytor_nazwa,
            p.nazwa_przewoznika AS przewoznik_nazwa,
            p.nr_rejestracyjny AS przewoznik_rejestracja,
            p.ladownosc AS przewoznik_ladownosc,
            pod.id_pliku AS pod_id_pliku,
            pod.nazwa_pliku AS pod_nazwa_pliku,
            pod.sciezka_pliku AS pod_sciezka_pliku,
            pod.data_wgrania AS pod_data_wgrania,
            pod.zweryfikowany AS pod_zweryfikowany
        FROM Zlecenia z
        JOIN Klienci k ON k.id_klienta = z.id_klienta
        LEFT JOIN Spedytorzy s ON s.id_spedytora = z.id_spedytora
        LEFT JOIN Uzytkownicy us ON us.id_uzytkownika = s.id_spedytora
        LEFT JOIN Przewoznici p ON p.id_przewoznika = z.id_przewoznika
        LEFT JOIN DokumentyPOD pod ON pod.id_zlecenia = z.id_zlecenia
    """
    params = []
    conditions = []
    if id_klienta is not None:
        conditions.append("z.id_klienta = ?")
        params.append(id_klienta)
    if id_przewoznika is not None:
        conditions.append("z.id_przewoznika = ?")
        params.append(id_przewoznika)

    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY z.id_zlecenia DESC"
    return db.execute(query, params).fetchall()


def znajdz_po_numerze(nr_zlecenia: str):
    """F03 (UC2): Wyszukuje zlecenie po unikalnym numerze nr_zlecenia."""
    nr_zlecenia = (nr_zlecenia or "").strip().upper()
    if not nr_zlecenia:
        return None
    db = get_db()
    return db.execute(
        """
        SELECT
            z.*,
            k.nazwa_podmiotu AS klient_nazwa,
            k.typ_klienta AS klient_typ,
            us.nazwa_wyswietlana AS spedytor_nazwa,
            p.nazwa_przewoznika AS przewoznik_nazwa,
            p.nr_rejestracyjny AS przewoznik_rejestracja,
            pod.nazwa_pliku AS pod_nazwa_pliku,
            pod.zweryfikowany AS pod_zweryfikowany
        FROM Zlecenia z
        JOIN Klienci k ON k.id_klienta = z.id_klienta
        LEFT JOIN Spedytorzy s ON s.id_spedytora = z.id_spedytora
        LEFT JOIN Uzytkownicy us ON us.id_uzytkownika = s.id_spedytora
        LEFT JOIN Przewoznici p ON p.id_przewoznika = z.id_przewoznika
        LEFT JOIN DokumentyPOD pod ON pod.id_zlecenia = z.id_zlecenia
        WHERE UPPER(z.nr_zlecenia) = ?
        """,
        (nr_zlecenia,),
    ).fetchone()
