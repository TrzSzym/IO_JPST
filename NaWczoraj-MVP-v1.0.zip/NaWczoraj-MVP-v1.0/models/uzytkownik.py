from db import get_db


def pobierz_klientow():
    db = get_db()
    return db.execute(
        """
        SELECT k.id_klienta, k.nazwa_podmiotu, k.typ_klienta, k.miasto, k.telefon, k.nip, u.email
        FROM Klienci k
        JOIN Uzytkownicy u ON u.id_uzytkownika = k.id_klienta
        ORDER BY k.id_klienta
        """
    ).fetchall()


def pobierz_spedytorow():
    db = get_db()
    return db.execute(
        """
        SELECT s.id_spedytora, s.poziom_uprawnien, s.region, u.nazwa_wyswietlana, u.email
        FROM Spedytorzy s
        JOIN Uzytkownicy u ON u.id_uzytkownika = s.id_spedytora
        ORDER BY s.id_spedytora
        """
    ).fetchall()


def pobierz_przewoznikow():
    db = get_db()
    return db.execute(
        """
        SELECT p.id_przewoznika, p.nazwa_przewoznika, p.nr_rejestracyjny, p.ladownosc, u.email
        FROM Przewoznici p
        JOIN Uzytkownicy u ON u.id_uzytkownika = p.id_przewoznika
        ORDER BY p.id_przewoznika
        """
    ).fetchall()
