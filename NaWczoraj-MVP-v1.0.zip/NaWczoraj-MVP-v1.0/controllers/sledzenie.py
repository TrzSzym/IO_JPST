from flask import Blueprint, render_template, request
from models.zlecenie import pobierz_zlecenia, znajdz_po_numerze

bp = Blueprint("sledzenie", __name__, url_prefix="/sledzenie")


@bp.get("/")
def status():
    nr = request.args.get("nr", "").strip()
    wynik = znajdz_po_numerze(nr) if nr else None
    wszystkie = pobierz_zlecenia()
    return render_template("sledzenie/status.html", nr=nr, wynik=wynik, wszystkie=wszystkie)
