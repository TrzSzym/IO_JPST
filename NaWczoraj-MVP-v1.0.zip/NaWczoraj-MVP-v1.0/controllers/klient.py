from flask import Blueprint, flash, redirect, render_template, request, url_for
from models.uzytkownik import pobierz_klientow
from models.zlecenie import oplac_zlecenie, pobierz_zlecenia, utworz_zapytanie

bp = Blueprint("klient", __name__, url_prefix="/klient")


@bp.get("/")
def panel():
    id_klienta = request.args.get("klient_id", default=1, type=int)
    klienci = pobierz_klientow()
    zlecenia = pobierz_zlecenia(id_klienta=id_klienta)
    aktywny_klient = next((k for k in klienci if k["id_klienta"] == id_klienta), klienci[0] if klienci else None)
    return render_template(
        "klient/panel.html",
        klienci=klienci,
        aktywny_klient=aktywny_klient,
        zlecenia=zlecenia,
    )


@bp.post("/zapytanie")
def nowe_zapytanie():
    id_klienta = request.form.get("id_klienta", default=1, type=int)
    ok, komunikat, _ = utworz_zapytanie(
        id_klienta=id_klienta,
        rodzaj_towaru=request.form.get("rodzaj_towaru", ""),
        waga_raw=request.form.get("waga_kg", ""),
        wymagana_chlodnia=request.form.get("wymagana_chlodnia") == "1",
        miejsce_zaladunku=request.form.get("miejsce_zaladunku", ""),
        miejsce_rozladunku=request.form.get("miejsce_rozladunku", ""),
        data_zaladunku=request.form.get("data_zaladunku", ""),
        uwagi=request.form.get("uwagi", ""),
    )
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("klient.panel", klient_id=id_klienta))


@bp.post("/oplac/<int:id_zlecenia>")
def oplac(id_zlecenia: int):
    id_klienta = request.form.get("id_klienta", default=1, type=int)
    ok, komunikat = oplac_zlecenie(id_zlecenia)
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("klient.panel", klient_id=id_klienta))
