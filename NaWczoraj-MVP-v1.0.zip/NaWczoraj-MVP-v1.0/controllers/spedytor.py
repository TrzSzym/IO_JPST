from flask import Blueprint, flash, redirect, render_template, request, url_for
from models.dokument_pod import zweryfikuj_i_rozlicz_zlecenie
from models.uzytkownik import pobierz_przewoznikow, pobierz_spedytorow
from models.zlecenie import oplac_zlecenie, pobierz_zlecenia, przydziel_przewoznika, wycen_zlecenie

bp = Blueprint("spedytor", __name__, url_prefix="/spedytor")


@bp.get("/")
def pulpit():
    spedytorzy = pobierz_spedytorow()
    przewoznicy = pobierz_przewoznikow()
    zlecenia = pobierz_zlecenia()
    aktywny_spedytor = spedytorzy[0] if spedytorzy else None
    return render_template(
        "spedytor/pulpit.html",
        aktywny_spedytor=aktywny_spedytor,
        przewoznicy=przewoznicy,
        zlecenia=zlecenia,
    )


@bp.post("/wycen/<int:id_zlecenia>")
def wycen(id_zlecenia: int):
    id_spedytora = request.form.get("id_spedytora", default=3, type=int)
    cena_netto = request.form.get("cena_netto", "")
    ok, komunikat = wycen_zlecenie(id_zlecenia=id_zlecenia, id_spedytora=id_spedytora, cena_netto_raw=cena_netto)
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("spedytor.pulpit"))


@bp.post("/potwierdz-platnosc/<int:id_zlecenia>")
def potwierdz_platnosc(id_zlecenia: int):
    ok, komunikat = oplac_zlecenie(id_zlecenia)
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("spedytor.pulpit"))


@bp.post("/przydziel/<int:id_zlecenia>")
def przydziel(id_zlecenia: int):
    id_przewoznika = request.form.get("id_przewoznika", type=int)
    if not id_przewoznika:
        flash("Wybierz przewoźnika z listy przed zatwierdzeniem transportu.", "error")
        return redirect(url_for("spedytor.pulpit"))
    ok, komunikat = przydziel_przewoznika(id_zlecenia=id_zlecenia, id_przewoznika=id_przewoznika)
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("spedytor.pulpit"))


@bp.post("/rozlicz/<int:id_zlecenia>")
def rozlicz(id_zlecenia: int):
    ok, komunikat = zweryfikuj_i_rozlicz_zlecenie(id_zlecenia)
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("spedytor.pulpit"))
