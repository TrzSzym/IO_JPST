from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for
from models.dokument_pod import zapisz_dokument_pod
from models.uzytkownik import pobierz_przewoznikow
from models.zlecenie import aktualizuj_lokalizacje, pobierz_zlecenia

bp = Blueprint("przewoznik", __name__, url_prefix="/przewoznik")


@bp.get("/")
def panel():
    przewoznik_id = request.args.get("przewoznik_id", default=4, type=int)
    przewoznicy = pobierz_przewoznikow()
    aktywny_przewoznik = next(
        (p for p in przewoznicy if p["id_przewoznika"] == przewoznik_id),
        przewoznicy[0] if przewoznicy else None,
    )
    zlecenia = pobierz_zlecenia(id_przewoznika=aktywny_przewoznik["id_przewoznika"]) if aktywny_przewoznik else []
    return render_template(
        "przewoznik/panel.html",
        przewoznicy=przewoznicy,
        aktywny_przewoznik=aktywny_przewoznik,
        zlecenia=zlecenia,
    )


@bp.post("/lokalizacja/<int:id_zlecenia>")
def lokalizacja(id_zlecenia: int):
    przewoznik_id = request.form.get("przewoznik_id", default=4, type=int)
    nowa_lokalizacja = request.form.get("aktualna_lokalizacja", "")
    ok, komunikat = aktualizuj_lokalizacje(id_zlecenia=id_zlecenia, nowa_lokalizacja=nowa_lokalizacja)
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("przewoznik.panel", przewoznik_id=przewoznik_id))


@bp.post("/pod/<int:id_zlecenia>")
def wgraj_pod(id_zlecenia: int):
    przewoznik_id = request.form.get("przewoznik_id", default=4, type=int)
    plik = request.files.get("plik_pod")
    ok, komunikat = zapisz_dokument_pod(
        id_zlecenia=id_zlecenia,
        plik=plik,
        upload_folder=current_app.config["UPLOAD_FOLDER"],
    )
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("przewoznik.panel", przewoznik_id=przewoznik_id))
