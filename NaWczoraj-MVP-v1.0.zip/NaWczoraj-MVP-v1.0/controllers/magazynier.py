from flask import Blueprint, flash, redirect, render_template, request, url_for
from models.zlecenie import obsluz_rampe, pobierz_zlecenia

bp = Blueprint("magazynier", __name__, url_prefix="/magazynier")

MAGAZYNY_RAMPA = [
    "Rampa 1 – Centrala Łódź",
    "Rampa 2 – Hub Warszawa",
    "Rampa 3 – Hub Poznań",
    "Rampa 4 – Hub Katowice",
]


@bp.get("/")
def rampa():
    zlecenia = pobierz_zlecenia()
    return render_template("magazynier/rampa.html", zlecenia=zlecenia, rampy=MAGAZYNY_RAMPA)


@bp.post("/operacja/<int:id_zlecenia>")
def operacja(id_zlecenia: int):
    rampa_nr = request.form.get("rampa_nr", MAGAZYNY_RAMPA[0])
    typ_operacji = request.form.get("typ_operacji", "zaladunek")
    ok, komunikat = obsluz_rampe(id_zlecenia=id_zlecenia, rampa_nr=rampa_nr, operacja=typ_operacji)
    flash(komunikat, "success" if ok else "error")
    return redirect(url_for("magazynier.rampa"))
